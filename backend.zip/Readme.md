# VMS Backend

Here are some Information For the VMS Backend To use Rest API's
